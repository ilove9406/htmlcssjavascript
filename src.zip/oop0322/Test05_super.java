package oop0322;

public class Test05_super {

	public static void main(String[] args) {
		//super, super()와 this, this() 활용한 클래스 설계
		
		//Parent클래스 생성

		
		
		
		
		Child child =new Child(10,20,30);
		
		System.out.println(child.one);
		System.out.println(child.two);
		System.out.println(child.three);
		
		
		
		
		
		
		
		
		
		
		
		
	}//main() end

}//class end
