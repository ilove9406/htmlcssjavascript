package oop0322;

public class Test01_getset {

	public static void main(String[] args) {
		
		
		//getter 와 setter함수
		
		/*
		 * 
		 * 함수명 작성 규칙
		 * is 함수명 () 대부분 boolean 형으로 반환
		 * to 함수명() to 뒤의 값을 반환
		 * get 함수명() 대부분 리턴값이 존재
		 * set 함수명() 원하는 값으로 세팅할 때
		 * 
		 * 
		 * */
		
		//getter 함수명 작성 규칙
		// -> get 멤버 변수의 첫 글자 대문자 바꾼 후 함수명()
		
		
		
		//setter 함수명 작성 규칙
		// -> set 멤버 변수의 첫 글자 대문자 바꾼 후 함수명()
		// BbsDTO 클래스 생성 후 실습합니다.

	
		BbsDTO bDto =new BbsDTO();
		
		bDto.setBbsno(1);
		bDto.setWriter("오필승");
		bDto.setSubject("무궁화 꽃이 피었습니다.");
		
		System.out.println(bDto.getBbsno());
		System.out.println(bDto.getWriter());
		System.out.println(bDto.getWriter());
	
	}

	
	
}
