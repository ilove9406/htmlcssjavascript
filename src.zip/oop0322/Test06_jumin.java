package oop0322;

public class Test06_jumin {

	public static void main(String[] args) {
		
		
		
		
		
		//문제) 주민번호 유효성 검사
		//Jumin 클래스 생성
		//참조 http://pretyimo.cafe24.com/lectureRead.do?lectureno=154

		
		
		Jumin id= new Jumin("9610151018417");
		
		
		if(id.isValidate()) {
			System.out.println("주민번호 맞다");
			id.disp();
		} else {
			System.out.println("주민번호 틀리다");
		}//if end
		
		
		
		
		
	}//main() end

}//class end
