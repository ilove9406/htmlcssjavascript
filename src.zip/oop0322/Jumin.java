package oop0322;
import java.util.Calendar;
import java.util.GregorianCalendar;
public class Jumin {

    private String juminno; //주민번호
    
    public Jumin () {}
    public Jumin(String juminno) {
        this.juminno=juminno;
    }//end
    
    
    public boolean isValidate() {
        boolean flag = false; // 초기값은 false로 설정

        Integer[] CHECKNUM = { 2, 3, 4, 5, 6, 7, 8, 9, 2, 3, 4, 5 };
        Integer[] save =new Integer[12];
        int size =save.length; //12
        int hap =0;
        
        for(int i=0; i<size;i++) {
            //주민번호에서 한글자씩 가져와서 정수형 변환
            int num =Integer.parseInt(juminno.substring(i,i+1));
            save[i] =num* CHECKNUM[i]; //8*2
            hap=hap+save[i];
        }//for end
        
        //오류 검증 번호
        int M=(11-((hap)%11))%10;
        
        //오류검증번호와 주민번호 마지막 글자와 같은지?
        if(M== Integer.parseInt(juminno.substring(12))) {
            flag=true;
        }//if end
        return flag;
    }//isValidate() end

    //문제 생년월일, 성별,나이,띠,살아온 날수 출력하기
    /*
        생년월일  : 1989년 12월 30일
        성별        : 남자 
        나이        : 35 -> GregorianCalendar클래스 이용
        띠        :  ->태어난%12 (0원숭이 1닭 2개 ~~ 11양) 
        살아온 날수: 12502일
    */
    

    public void disp() {
        if (isValidate()) {
            
             // 성별 판별 "1" ->1
            int myCode =Integer.parseInt(juminno.substring(6,7));            
            
            // 생년월일 추출
            int myYear = Integer.parseInt(juminno.substring(0, 2));
            int myMonth = Integer.parseInt(juminno.substring(2, 4));
            int myDay = Integer.parseInt(juminno.substring(4, 6));
            
            // 생년 계산
            switch(myCode) {
                case 1:
                case 2: myYear+=1900; break;
                case 3: 
                case 4: myYear+=2000; break;
            }//switch end

            // 현재 연도 가져오기
            Calendar now = Calendar.getInstance();
            int cYear = now.get(Calendar.YEAR);

            // 나이 계산
            int myAge = cYear - myYear;
            
            
            String gender="";
            switch(myCode%2) {
                case 0: gender="여자"; break;
                case 1: gender="남자"; break;
            } //switch end

            // 띠 판별
            String[] animal = {"쥐", "소", "호랑이", "토끼", "용", "뱀", "말", "양", "원숭이", "닭", "개", "돼지"};//12간지
            int animalIndex =(myYear - 4) % 12;
            String zodiac = animal[animalIndex];

            // 살아온 날 수 계산 
            GregorianCalendar myBirth = new GregorianCalendar();
            myBirth.set(Calendar.YEAR, myYear);
            myBirth.set(Calendar.MONTH, myMonth-1);
            myBirth.set(Calendar.DATE, myDay);
            
            int alive=0;
            Calendar nowCal = Calendar.getInstance();
            while (!myBirth.after(nowCal)) {
                alive++;
                myBirth.add(Calendar.DATE,1);
            }//while end
            
            // 정보 출력
            System.out.println("생년월일 : " + myYear + "년 " + myMonth + "월 " + myDay + "일");
            System.out.println("성별     : " + gender);
            System.out.println("나이     : " + myAge);
            System.out.println("띠       : " + zodiac);
            System.out.println("살아온 날 수: " + alive + "일");
        }  else {
            System.out.println("유효하지 않은 주민등록번호입니다.");
        }//disp() end
    }
}
