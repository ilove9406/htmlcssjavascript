package oop0322;

import java.lang.*;//생략가능


class Seoul extends Object{}


class Jeju extends Object{
	@Override
	public String toString() {
		return "제주도";	//상속받은 메소드를 재정의 ==override
		
	}
} //class end

class Suwon extends Object{
	private String id= "itwill";
	private String pw="1234";

	@Override
	public String toString() {
		return "Suwon [id="+id+", pw="+pw+"]";		//클래스 안의 특별한 데이터 값을 확인하는 용도로 많이쓰는 방식임
	}

}//class end



class Incheon extends Object{
	private String name="인천 광역시";
	private String phone="789-8745";
	//메뉴 Source -> Generate toString()...
	@Override
	public String toString() {
		return "Incheon [name=" + name + ", phone=" + phone + "]";
	}

}//class end


public class Test03_Object extends Object {// extends Object 생략 가능

	public static void main(String[] args) {
		//Object 클래스
		//교재참조 :CHAPTER 11 기본 API 클래스
		
		/*
		 	* -자바의 최고 조상 클래스 : ObJect클래스
		 	* -자바의 기본 패키지 (java.lang)에 선언되어 있음
		 	* -자바의 모든 클래스는 무조건 Object를 상속 받는다.
		 	* -자바의 모든 클래스는 Object클래스의 후손들이다.
		 */
		//메모리 할당을 정상적으로 함. 출력: oop0322.Seoul@2133c8f8
		Seoul se= new Seoul();
		System.out.println(se.toString());
		
		Jeju je	=new Jeju();
		System.out.println(je.toString());
		
		Suwon su=new  Suwon();
		System.out.println(su.toString());

		Incheon in=new Incheon();
		System.out.println(in.toString());
		
		//함수 이름 toString () 생략 가능
		//toString ()함수는 개발하는 과정에서 에러체크하는 경우에 많이 사용한다.
		System.out.println(se);
		System.out.println(je);
		System.out.println(su);
		System.out.println(in);
		
		se=null;
		System.out.println(se);
	}

}
