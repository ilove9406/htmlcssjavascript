package oop0322;

public class MemgerDTO {

	
	
	//멤버변수  field
	private int memberno;//일련번호
	private String userid;//아이디
	private String password;//비밀번호
	private String email;//이메일
	
	
	
	//생성자 함수 construct
	public MemgerDTO() {
		
	}

	public MemgerDTO(int memberno, String userid, String password, String email) {
		this.memberno = memberno;
		this.userid = userid;
		this.password = password;
		this.email = email;
	}
	
	
	//멤버함수 method
	//getter/setter()는 필드의 직접접근제한을 메소드를 통한 간접접근제한하기위해 사용.
	//이 메소드로 매개값 검증해서 유효한 데이터값 객체의 필드로 저장할 수 있다.
	public int getMemberno() {
		return memberno;
	}

	public void setMemberno(int memberno) {
		this.memberno = memberno;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}// class end
