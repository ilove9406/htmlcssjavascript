package oop0326;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class Test01_List {

	public static void main(String[] args) {
		//Java Collection Framework
		//자료를 모아서 저장할 수 있는 클래스 및 인터페이스
		
		/*
		 
		 List : 순서(Index)가 있다. 인덱스는 0부터 시작 
		 		Vector, ArrayList, ~~
		 Set  : 순서가 없다
		 		HashSet, ~~
		 Map  : 순서가 없다. Key와 Value로 구성되어 있다. CSS JSON
		 		HashMap,Properties, ~~
		 		
		 		
		 		
		 		Interface Collection {}
		 	
		 	
		 		Interface List extends Collection{}
		 		class  Vector implements List{}
		 		class ArrayList implements List{}
		 		
		 		Interface Set extends Collection {}
		 		class HashSet implements Set {}
		 		
		 		Interface Map{}
		 		class HashMap implements Map
		 		class Properties Map{}
		 	
		 	
		 	//다형성 (부모가 자식 집에 들어갈 수 있다.)
		 	 List list =new List Vector()
		 	 List list =new ArrayList()
		 	 Set set =new HashSet()
		 	 Map map  = new HashMap()
		 	 Map map =newProperties()

		 */
		

		//배열 : 자료 모아 놓을 수 있음
		int [] num =new int[100];
		
		//열거형
		//Enumeration
		
		//1. List 계열 
		//제네릭 <E> Element 요소
		List vec =new Vector();
		vec.add(3);
		vec.add(2.4);
		vec.add('R');
		vec.add("KOREA");
		vec.add(new Integer(5));
		vec.add(new Double(6.7));
		
		//Integer inte =new Integer(5); old version
		//Integer inte =5; 				new version
		
		System.out.println(vec.size());// 요소의 갯수
		
	
			
		for(int i=0; i<vec.size();i++) {
			System.out.println(vec.get(i));
		
		}//for end
		
		
		vec.remove(0);					//0번쨰 요소 제거하기
		System.out.println(vec.size());	//5
		
		
		vec.remove(0);
		System.out.println(vec.size());
		
		vec.clear(); // vec 리스트 비우기

		System.out.println(vec.size());	//0
		
		if(vec.isEmpty()) {//요소 갯수가 0개인지?
			System.out.println("비어 있다.");
		} else {
			System.out.println("비어 있지 않다.");
		}//if end
		
		
		
		//다형성
		List list =new ArrayList();
		list.add(vec);
		list.add(5);
		list.add(6.7);
		list.add('M');
		list.add("SEOUL");
		list.add(new String("대한민국"));
		
		System.out.println(list.size());//5
		
		//문제 ) remove() 이용해서 list요소를 전부 삭제하시오.
		
		for (int i=0; i<list.size();i++) {
			list.remove(i);
		}// for end
		
		System.out.println(list.size());//0
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}//main() end

}//class end
