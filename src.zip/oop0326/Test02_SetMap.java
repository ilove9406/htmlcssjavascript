package oop0326;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

public class Test02_SetMap {

	public static void main(String[] args) {
		//2. Set 계열 : 순서가 없다
		
		
		Set set =new HashSet();
		set.add(3);
		set.add(2.4);
		set.add('R');
		set.add("BUSAN");
		set.add(new Integer(7));
		
		System.out.println(set.size());
		
		
		//cursor :가리킬 요소가 있으면  true, 없으면 false
		//cursor를 이용해서 요소를 접근하는 경우
		
		Iterator iter= set.iterator();
		
		while(iter.hasNext()) { 		//다음 cursor가 있는지?
			Object obj =iter.next();	//cursor가 가리키는 요소 가져오기
			System.out.println(obj);
		}//while end
		

	
		
		//3. Map 계열 : 순서가 없다

		//->Key	:이름표
		//->Value:값
		
		//CSS JSON NoSQL PYTHON(딕셔너리) 등에서 많이 씀
	
		HashMap map =new HashMap();
		
		map.put("one",3 );
		map.put("two", 2.4);
		map.put("three", 'R');
		map.put("four", "손흥민");
		
		System.out.println(map.size());//4
		System.out.println(map.get("one"));
		System.out.println(map.get("four"));
		
		map.put("four", "박지성");
		System.out.println(map.get("four"));
		
		//Properties 클래스
		
		Properties db=new Properties();
		db.put("url", "http://localhost:1521" );
		db.put("username","itwill" );	
		db.put("password", "12341234");
		
		
		System.out.println(db.get("url"));
		System.out.println(db.get("username"));
		System.out.println(db.get("password"));
		
		
		
		//문제)= command변수값에서 '=' 문자를 기준으로 문자열 분리
		//		'='앞의 문자열은 key, '='뒤의 문자열은 value로 구분해서 hm에 저장하고
		//		 예를 들어 ) hm의 key값들 중에서 "readdo"를 호출하면 value값으로 nut.bbs.read를 호출하면
		//					value값으로 net.bbs.Read출력하시오.
		HashSet command=new HashSet();
		command.add("list.do=net.bbs.read");
		command.add("read.do=net.bbs.List");
		command.add("write.do=net.bbs.white");
		
		System.out.println(command.size());
		
		 HashMap hm = new HashMap();
		 //1)커서 생성하기
	        Iterator cursor = command.iterator();
	     //2)커서가 있을때까지 반복
	        while (cursor.hasNext()) {//다음 cursor가 있는지?
	     //3)커서가 가리키는 요소를 가져와서 문자열 형변환
	        	Object obj = cursor.next();//cursor가 가리키는 요소 가져오기
	            String line = (String)obj;
	            //String line =(String)cursor.next();
	     //4) "=" 위치를 기준으로 문자열 분리하기
	   	 //-> split(), substring(), StringTokenizer클래스   
	     
	            String[] word = line.split("=");
	            String key = word[0];	//"=" 앞 문자열
	            String value = word[1]; // "=" 뒤 문자열
	            
//	            System.out.println(key);
//	            System.out.println();
	            
	     //5)hm에 저장하기
	            hm.put(key, value);
	            
	        }//while end
	    
	        
		//결과값 
		System.out.println(hm.get("read.do"));//net.bbs.Read
		System.out.println(hm.get("list.do"));
		System.out.println(hm.get("write.do"));
		
	}//main () end

}//class end
