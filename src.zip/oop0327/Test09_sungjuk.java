package oop0327;



import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Test09_sungjuk {

    public static void main(String[] args) {
        // 성적 입력 파일 경로 및 출력 결과 파일 경로
        String isName = "E:/java202401/sungjuk.txt";
        String outName = "E:/java202401/result.txt";

        // 파일 입출력을 위한 변수들
        FileReader fr = null;
        BufferedReader br = null;
        
        FileWriter fw = null;
        PrintWriter out = null;

        try {
        	//1)단계: 데이터 저장 변수 선언
        	String[] name=new String [5];
        	int [] kor =new int[5];
        	int [] eng = new int [5];
        	int [] mat =new int [5];
        	
        	int [] aver=new int [5];
        	int [] rank= {1,1,1,1,1};
        	int i=0;
        	
        	//2)단계: 데이터 입력 파일 (sungjuk.txt) 가져와서 내용을 읽기
            fr = new FileReader(isName);//sungjuk.txt 가져오기
            br = new BufferedReader(fr);//엔터를 기준으로 끊어서 읽어 오기 위해 BufferedReader에 옮겨 담기
            String line =null;
            
            while(true) {
            	line =br.readLine();//"무궁화,95,90,100"
            	if(line==null) {
            		break;
            	}//if end
            	System.out.println(line);
            	
            	//,를 기준으로 문자열 분리한 후 1)단계에서 선언한 변수에 저장하기
            	//과제 ) StringTokenizer 클래스를 이용해서 문자열 분리해보기
            	String [] word = line.split(",");
            	name[i]=word[0].trim();//"무궁화"
            	kor[i]=Integer.parseInt(word[1].trim());//95
            	eng[i]=Integer.parseInt(word[2].trim());//90
            	mat[i]=Integer.parseInt(word[3].trim());//100
            	i++;//다음사람
            }//while end
            //3)단계 : 평균구하기
            		for(i=0; i<aver.length;i++) {
            			aver[i] = (kor[i] + eng[i] + mat[i]) / 3;
            		}//for end
            //4)단계 : 등수 구하기 (평균을 기준으로)
            for(int a=0; a<aver.length;a++) {
            	for(int b=0;b<aver.length;b++) {
            		if(aver[a]<aver[b]) {
            			rank[a]=rank[a]+1;//rank[a]++
            		}//if  end
            	}//for end
            }//for end

            
            //5)단계 : result.txt 결과 출력하기
            fw = new FileWriter(outName,false);
            out = new PrintWriter(fw,true);

            
            
            // 결과 파일에 헤더 출력
            out.println("성 / 적 / 결 / 과");
            out.println("-------------------------------------------------------");
            out.println("이름       국어   영어   수학   평균   등수   결과");
            out.println("-------------------------------------------------------");

            //참조 oop0315.Test07_format클래스
            // 	  out.printf()
            
            //6)단계 : 5명의 데이터 출력하기
            for(i=0;i<aver.length;i++) {
            	out.printf("%-6s %5d %5d %5d %5d %5d",name[i],kor[i],eng[i],aver[i],rank[i]);
            
            	if(aver[i]>=70) {
            		if(kor[i]<40||eng[i]<40||mat[i]>40) {
            			out.printf("%-5s","재시험"); //5칸내에서 왼쪽정렬
            		} else {
            			out.printf("%-5s","합격");
            		}//if end
            	} else {
            		out.printf("%-5s","불합격");
            	} //if end
            	
            	for (int star=0; star<aver[i]/10; star++) {
            		out.print("*");
            	}//for end
            	
            	if (aver[i]>95) {out.printf("%-12s","장학생");//12칸내에서 오른쪽 정렬
            	}
            out.println();
            }//for end



        } catch (Exception e) {
            // 오류 발생 시 예외 처리
            System.out.println("성적 프로그램 읽기, 쓰기 실패:" + e);
        } finally {
            // 파일 닫기
            try {
                if (br != null) {
                    br.close();
                }
            } catch (Exception e) {
            }

            try {
                if (out != null) {
                    out.close();
                }
            } catch (Exception e) {
            }

            try {
                if (fw != null) {
                    fw.close();
                }
            } catch (Exception e) {
            }

        }// end

    }

 
    

}// class end
