package oop0327;

import java.io.FileInputStream;

public class Test05_input {

	public static void main(String[] args) {
		// 파일 입출력(파일 입출력(.txt)
		// 파일 : .txt .csv .xls .ppt .jpg
		
		//byte 형 : 1byte 할당
		//char 형 : 2byte 할당
		
		//1.byte 기반 -> 한글 깨짐
		
		String filename="E:\\java202401\\workspace\\basic01_java\\src\\oop0327\\data.txt";
		
		FileInputStream fis= null;
		
		try {
			fis =new FileInputStream(filename);
			
			while (true) {
				int data =fis.read();//1바이트 읽기
				if( data==-1) {//파일의 끝인지? 
					
				}//if end
				System.out.printf("%c",data);
			}//while end
			
			
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			//자원반납
			try {
				if(fis!=null) {fis.close();}
			} catch (Exception e) {}
		}
		
		
	
	
	}//main() end

}//class end

