package oop0327;

import java.io.FileReader;

public class Test06_input {

	public static void main(String[] args) {
		//2.char기반 ->한글 안 깨짐

		String filename="E:\\java202401\\workspace\\basic01_java\\src\\oop0327\\data.txt";
		
		FileReader fr =null;
		
		try {
			
			fr= new FileReader(filename);
			
			while(true) {
				int data =fr.read();//2바이트 읽기
				if(data==-1) {//파일의 끝 End of File?
					break;
				}//if end
				System.out.printf("%c",data);
			}//while end
			
			
			
			
			
		}catch (Exception e) {
			System.out.println("파일 읽기 실패:"+e);
		}finally {
			//자원 반납
			try {
				if(fr!=null) {fr.close();}
			} catch(Exception e) {}
		}//end
		
	}//main ()end

}//class end
