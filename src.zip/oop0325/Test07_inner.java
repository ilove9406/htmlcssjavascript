package oop0325;

public class Test07_inner {

	public static void main(String[] args) {
		// 중첩 클래스
		//내부 클래스, inner class
		//->클래스 내부에 선언된 클래스
		
		
		//WebProgram 클래스 생성
		
		
		
		
	}//main() end

}//class end
