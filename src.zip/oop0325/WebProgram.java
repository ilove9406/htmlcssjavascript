package oop0325;
//웹페이지를 작성할 때 사용하는 언어
	//.jsp .py .php .asp
	
	//CSS Framework 	 : Bootstrap
	//JSP Framework 	 : Spring Framwork, Spring Boot, Struts
	//PYTHON Framework : Django, Flask
public class WebProgram {

	
	
	
	String title ="JAVA Program";
	
	class Language {
		String basic="JAVA,HTML,CSS,JavaScript";
		void display() {
			System.out.println("기초수업:"+basic);
		}//end
	}// inner class 
	
	class Smart {
		String basic="Objective-C, Java OOP, C#";
		void display() {
			System.out.println("기초수업:"+basic);
		}//end
	} //inner class 
	
	
	
	
	
	
	
}// class end
