package oop0325;

import oop0325.Creature.Salmon;
import oop0325.Creature.Tiger;

public class Test04_interface {

	public static void main(String[] args) {

		//인터페이스  interface
		
		/*
		 * 
		 * 추상메소드로만 구성되어 있다.
		 * 추상클래스보다 더 추상화 되어 있다.
		 * 상속 : extends 확장, implements 구현
		 * 
		 * 
		 * */
		
		//Creature 인터페이스 생성후 실습
		//에러. 인터페이스는 직접 객체 생성 불가능
		//Creature = new Creature();
		
		//인터페이스와 다형성
		Creature creature= null;
		
		creature=new Tiger();
		creature.kind();
		creature.breathe();
		
		creature=new Salmon();
		creature.kind();
		creature.breathe();
		
		
		
		
	}//main() end

}//class end
