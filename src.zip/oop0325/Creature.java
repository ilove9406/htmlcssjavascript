package oop0325;

interface Creature {

	
	//void disp() {} 에러. 일반 메소드 사용불가
	abstract void kind();	//추상메소드만 가능하다.
	void breathe();			//abstract  생략가능
	
	
	
	class Tiger implements Creature{
		@Override
		public void breathe() {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void kind() {
			System.out.println("허파");
			
		}
	} //class end
	
	
	class Salmon implements Creature{
		@Override
		public void breathe() {
			System.out.println("아가미");
		}
		@Override
		public void kind() {
			System.out.println("어류");			
		}
	}//class end
	
	
	
	
	
	
	
	
}// interface end
