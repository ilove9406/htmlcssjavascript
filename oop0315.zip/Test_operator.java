package oop0315;

public class Test_operator {

	public static void main(String[] args) {
		
		
		
		System.out.println(5/3);
		System.out.println(5/3);
		
		System.out.println(3/5);
		System.out.println(3%5);
		
		System.out.println(3.0/5.0);
		System.out.println(3/5.0);
		System.out.println(3.0/5);
		System.out.println(3/5.);
		
		
		System.out.println(5&3); //101 & 011 =001
		System.out.println(5|3); //101|011  =111
		
		System.out.println(~5);	 //0000 0101의 1의보수 ->1111 1010
		
		System.out.println(16<<3); //16*2의 3제곱
		System.out.println(16>>3); //16/2의 3제곱
	}

}
