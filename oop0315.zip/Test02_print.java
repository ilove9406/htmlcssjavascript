package oop0315;

public class Test02_print {

	public static void main(String[] args) {

		
	//System.out.println(); 콘솔창 출력 명령어
	//단축키 : syso 입력후 Ctrl+ space
		
		System.out.println(123);
		System.out.println("SEOUL");
		
		System.out.println("국어");
		System.out.println("영어");
		System.out.println("수학");
		
		System.out.println(123);
		System.out.println(456);
		System.out.println(789);
		
		System.out.println("\"");
		System.out.println("\'");
		System.out.println("\\");
		
		System.out.println(123+456);
		System.out.println("123"+"456");
		System.out.println(123+"456");
		System.out.println("123"+456);
		System.out.println("123+456");
	}

}
