package oop0315;

public class Test06_quiz {

	public static void main(String[] args) {
		
		
		
		//연습문제
		
		
		//참조 : 지폐 갯수 구하는 문제
		
		/*
		 * 
		 * 1년 :365.2422일
		 * 
		 * 
		 * 출력결과 :365일 5시간 48분 46초
		 * 
		 * 
		 * */
		double year=365.2422;
		int total=(int)(year*86400); // 1일 =86400초

		int day, hour, min, sec;

		day=total/86400;      //365일
		total=total%86400;

		hour=total/3600;      //5시간 		1시간 =3600초
		total=total%3600;

		min=total/60;         //48분  	1분=60초
		sec=total%60;         //46초  

		System.out.println("1년 : "+day+"일" + hour+"시간"+min+"분"+sec+"초");
	    
		
		//31556926
		

	}

}
